class Gameboardfield {
    id: string;
    next: string;

    constructor(id: string, next: string) {
        this.id = id;
        this.next = next;
    }
}

export {Gameboardfield};