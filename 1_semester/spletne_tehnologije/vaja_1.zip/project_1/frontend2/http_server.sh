#!/bin/bash
 python3 -m http.server 1245
