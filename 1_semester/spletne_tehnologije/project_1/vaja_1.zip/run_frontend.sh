#!/bin/bash
set -x
cd frontend2
pwd
./run_frontend.sh
