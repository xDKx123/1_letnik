use run.sh script to run the program.

chmod +x run.sh	//to run as script
