import 'package:easy_doctor/src/models/personal_list_model.dart';

List<PersonalListModel> personalListMock = <PersonalListModel>[
  PersonalListModel(
    id: PersonalListID('1'),
    name: 'Test 1',
    items: [],
    description: 'lorem ipsum',
  ),
  PersonalListModel(
    id: PersonalListID('1'),
    name: 'Test 2',
    items: [],
    description: 'lorem ipsum',
  ),
  PersonalListModel(
    id: PersonalListID('1'),
    name: 'Test 3',
    items: [],
    description: 'lorem ipsum',
  ),
  PersonalListModel(
    id: PersonalListID('1'),
    name: 'Test 4',
    items: [],
    description: 'lorem ipsum',
  ),
  PersonalListModel(
    id: PersonalListID('1'),
    name: 'Test 5',
    items: [],
    description: 'lorem ipsum',
  ),
];
