const String listPersonalListsRequest = '/getTaskLists';
const String updatePersonalListRequest = '/updateTaskList';
const String createPersonalListRequest = '/addTaskList';
const String deletePersonalListRequest = '/deleteTaskList';
