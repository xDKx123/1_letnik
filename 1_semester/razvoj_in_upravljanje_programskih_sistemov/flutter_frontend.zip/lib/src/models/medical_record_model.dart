import 'package:equatable/equatable.dart';

class MedicalRecordModel extends Equatable {
  const MedicalRecordModel();

  MedicalRecordModel copyWith() {
    return const MedicalRecordModel();
  }

  @override
  List<Object?> get props => <Object?>[];
}
