class LoginForm {
  LoginForm({this.email, this.password});

  String? email;
  String? password;
}
