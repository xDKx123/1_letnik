#include "configuration.h"

Configuration::Configuration()
{

}
